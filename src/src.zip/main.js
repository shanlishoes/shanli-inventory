import "./style.css";

import { startScanner } from "./scanner";

import {
  startNewSession,
  continueSession,
  finishSession,
  addItem
} from "./session";

import {
  startSessionApi,
  finishSessionApi,
  getSummary
} from "./api";

import { syncItem } from "./sync";

const beep = new Audio("/sounds/beep.mp3");

let session = null;
let qty = 1;
let count = 0;

document.querySelector("#app").innerHTML = `

<div class="container">

<div id="loginPage">

<div class="card">

<h1>📦 انبارگردانی شانلی</h1>

<input id="user" placeholder="نام انباردار">

<input id="supervisor" placeholder="نام ناظر">

<select id="branch">
<option>انبار مرکزی</option>
<option>شعبه شوط</option>
<option>شعبه ارومیه</option>
</select>

<button id="startBtn">
شروع انبارگردانی
</button>

</div>

</div>

<div id="scanPage" style="display:none">

<div class="topBar">

    <div class="infoCard">

        <div class="title">
            شعبه
        </div>

        <div id="branchName" class="value">
            شعبه مرکزی
        </div>

    </div>

    <div class="infoCard">

        <div class="title">
            ثبت شده
        </div>

        <div id="count" class="countValue">
            0
        </div>

    </div>

</div>

<div class="qtyCard">

    <div class="qtyTitle">
        تعداد
    </div>

    <div class="qtyRow">

        <button id="minus">−</button>

        <input
            id="qty"
            value="1"
            readonly>

        <button

</div>

; `


document.getElementById("startBtn").onclick = async () => {

  const user =
    document.getElementById("user").value.trim();

  const supervisor =
    document.getElementById("supervisor").value.trim();

  const branch =
    document.getElementById("branch").value;


  if (!user) {

    alert("نام انباردار را وارد کنید");

    return;

  }


session = continueSession();

if (
  session &&
  session.user.trim() === user.trim() &&
  session.status === "open"
) {

  const choice = prompt(
    "انبارگردانی باز دارید:\n\n" +
    "1 - ادامه قبلی\n" +
    "2 - بستن و شروع جدید"
  );


  if (choice === "2") {

    await finishSessionApi(session.id);

    finishSession();

    session = startNewSession(
      user,
      supervisor,
      branch
    );

  }


} else {

  session = startNewSession(
    user,
    supervisor,
    branch
  );

}


  const result = await startSessionApi({

    start: new Date().toLocaleString("fa-IR"),

    branch,

    user,

    supervisor

  });


  if (result.success && result.sessionId) {

    session.id = result.sessionId;

  }


  document.getElementById("loginPage")
  .style.display = "none";


  document.getElementById("scanPage")
  .style.display = "block";


  document.getElementById("branchName")
  .innerText = branch;


  // await startScanner(
//     "reader",
//     handleScan
// );


};
function handleScan(code) {

  document.getElementById("lastBarcode").innerText =
"آخرین بارکد: " + code;

document.getElementById("lastQty").innerText =
"✓ ثبت شد";
  document.getElementById("barcode").value = code;


  const qtyInput =
    document.getElementById("qty");

  qtyInput.focus();

  qtyInput.select();


  beep.currentTime = 0;

  beep.play();


  if (navigator.vibrate) {

    navigator.vibrate(100);

  }


  showPreviousQty(code);

}



async function showPreviousQty(code) {

  const result = await getSummary(code);


  if (result && result.success) {


    document.getElementById("lastQty").innerText =
      "قبلاً ثبت شده: " + result.qty + " عدد";


  } else {


    document.getElementById("lastQty").innerText =
      "اولین ثبت این بارکد";


  }

}
document.getElementById("plus").onclick = () => {

  qty++;

  document.getElementById("qty").value = qty;

};



document.getElementById("minus").onclick = () => {

  if (qty > 1) {

    qty--;

  }

  document.getElementById("qty").value = qty;

};





document.getElementById("barcode")
.addEventListener("input", function(){

  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const ar = "٠١٢٣٤٥٦٧٨٩";


  let value = this.value;


  value = value.replace(/[۰-۹]/g,
    d => fa.indexOf(d)
  );


  value = value.replace(/[٠-٩]/g,
    d => ar.indexOf(d)
  );


  value = value.replace(/\D/g,"");


  this.value = value;


  if(value){

    showPreviousQty(value);

  }


});





document.getElementById("saveBtn").onclick = async () => {


  const barcode =
    document.getElementById("barcode").value;



  if(!barcode){

    alert("بارکد را وارد کنید");

    return;

  }



  if(!session){

    alert("انبارگردانی فعال نیست");

    return;

  }



  const updated =
    addItem(barcode, qty);



  if(!updated){

    alert("Session پیدا نشد");

    return;

  }



  count = updated.count;


  document.getElementById("count")
  .innerText = count;



  syncItem(
  session,
  barcode,
  qty
).then(result => {

  if(result){
    console.log("ثبت شد ✅");
  }else{
    console.log("در انتظار ارسال 🟡");
  }

});



  qty = 1;


  document.getElementById("qty")
  .value = 1;


  document.getElementById("barcode")
  .value = "";


  document.getElementById("lastQty")
  .innerText = "اولین ثبت این بارکد";


};
document.getElementById("finishBtn").onclick = async () => {

  if(!session){
    alert("انبارگردانی فعالی وجود ندارد");
    return;
  }

  const answer = confirm(
    "آیا از پایان انبارگردانی مطمئن هستید؟"
  );

  if(!answer){
    return;
  }

  const result = await finishSessionApi(session.id);

  if(result.success){

    finishSession();

    alert("انبارگردانی با موفقیت پایان یافت");

    location.reload();

  }else{

    alert("خطا در پایان انبارگردانی");

  }

};
const barcodeInput = document.getElementById("barcode");

document.querySelectorAll(".num").forEach(btn => {
  btn.onclick = () => {
    barcodeInput.value += btn.innerText;
    showPreviousQty(barcodeInput.value);
  };
});

document.getElementById("back").onclick = () => {
  barcodeInput.value = barcodeInput.value.slice(0, -1);

  if (barcodeInput.value) {
    showPreviousQty(barcodeInput.value);
  } else {
    document.getElementById("lastQty").innerText =
      "اولین ثبت این بارکد";
  }
};

document.getElementById("clear").onclick = () => {
  barcodeInput.value = "";
  document.getElementById("lastQty").innerText =
    "اولین ثبت این بارکد";
};
